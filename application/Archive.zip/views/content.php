
<body>
<div id="wrap">
    <div class="container">
	<div class="page-header">
      <h1>iMLecturerr</h1>
      </div>
      <p class="lead"><form action="" method="GET">
                <div>
                    
                    <div>First name:        <br /> <input type=text id="fn" name='firstname'> </div>
                    <div>Last name:        <br />  <input type=text id="ln" name='lastname'> </div>
                    <div>Department Name:  <br />  <select  id="dt" name='dept'>
                        <option value="">Select Department</option>
                        <option value="Customer Service">Customer Service</option>
                        <option value="Development">Development</option>
                        <option value="Finance">Finance</option>
                        <option value="Human Resources">Human Resources</option>
                        <option value="Marketing">Marketing</option>
                        <option value="Production">Production</option>
                        <option value="Quality Management">Quality Management</option>
                        <option value="Research">Research</option>
                        <option value="Sales">Sales</option>
                    </select>
                    </div>
                    <div>Current job Title: <br /> <input type=text id="jt" name='jobtitle'> </div>
                    <br /><div><input value="Search" type="submit" id="search"></div>

            </form>
            <button id="reset">Reset</button>
            </br></br>
            <table><div id="result" class="row"></div></table>
</p>

    </div>
     <div id="push"></div>
     </div>
      </div>
  </div>
