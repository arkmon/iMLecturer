<?php include_once('header.php'); ?>
<?php include_once('navbar.php'); ?>
<?php include_once('content.php'); ?>
<?php include_once('footer.php'); ?>


